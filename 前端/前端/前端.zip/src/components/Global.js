const uName = ''
const uID = ''
const uPWD = ''

export default {
    uName,
    uID,
    uPWD
}
